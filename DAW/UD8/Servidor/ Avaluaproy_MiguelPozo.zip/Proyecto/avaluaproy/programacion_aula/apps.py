from django.apps import AppConfig

class ProgramacionAulaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'programacion_aula'
    #UD6.4.d
    verbose_name = 'PROGRAMACIÓN AULA'

    def ready(self):
        import programacion_aula.signals