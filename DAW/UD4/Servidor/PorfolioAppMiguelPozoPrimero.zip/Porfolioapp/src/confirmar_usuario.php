<?php include("templates/header.php"); ?>
<!--UD4.2.f BEGIN-->
<div class="container">
    <div class="alert alert-success mt-5">
        Usuario actualiado satisfactoriamente.
    </div>
    <div>
        <a class="btn btn-outline-secondary" href="/">
            Volver al inicio
        </a>
    </div>
</div>
<!--UD4.2.f END-->
<?php include("templates/footer.php"); ?>