from django.contrib import admin
from .models import Criptomoneda

# Register your models here.

admin.site.register(Criptomoneda)