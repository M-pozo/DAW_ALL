<?php include("templates/header.php"); ?>
<div class="container">
    <div class="alert alert-success mt-5">
        Ha contactado con nosotros satisfactoriamente. En breve nos pondremos en contacto con usted
    </div>
    <div>
        <a class="btn btn-xs btn-info float-right" href="/">
            Volver al inicio
        </a>
    </div>
</div>
<?php include("templates/footer.php"); ?>