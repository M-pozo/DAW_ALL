<?php include("templates/header.php"); ?>
<div class="container">
    <div class="alert alert-success mt-5">
        Usuario actualizado satisfactoriamente.
    </div>
    <div>
        <a class="btn btn-outline-secondary" href="/">
            Volver al inicio
        </a>
    </div>
</div>
<?php include("templates/footer.php"); ?>