<?php
    $servername = "mysql:3306";
    $username = "admin";
    $password = "admin";
    $db = "portfolio_db";
?>