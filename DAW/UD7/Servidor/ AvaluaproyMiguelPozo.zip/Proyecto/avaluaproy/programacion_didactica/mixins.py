from django.contrib.messages import constants as messages
from .models import PondRA, PondCriterio, PondCritUD

#UD7.2.g, UD7.2.h, UD7.2.i BEGIN

#UD7.2.g, UD7.2.h, UD7.2.i END